package classes;

public class TaxiwayPoint extends TaxiwayPointParking{
	
	public TaxiwayPoint(){
		super();
	}

	@Override
	public String getNumber() {
		// TODO Auto-generated method stub
		return null;
	}

}